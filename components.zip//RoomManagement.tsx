import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Home, Users, Clock, Wrench, CheckCircle, AlertCircle } from "lucide-react";

export function RoomManagement() {
  const roomStatuses = {
    vacant: { count: 25, color: "bg-green-500", label: "Vacant Clean" },
    occupied: { count: 85, color: "bg-red-500", label: "Occupied" },
    dirty: { count: 15, color: "bg-yellow-500", label: "Vacant Dirty" },
    maintenance: { count: 8, color: "bg-orange-500", label: "Out of Order" },
    cleaning: { count: 7, color: "bg-blue-500", label: "Being Cleaned" }
  };

  const rooms = Array.from({ length: 140 }, (_, i) => {
    const roomNumber = 100 + i + 1;
    const floor = Math.floor(roomNumber / 100);
    const statuses = ['vacant', 'occupied', 'dirty', 'maintenance', 'cleaning'];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
    
    return {
      number: roomNumber.toString(),
      floor: floor,
      type: roomNumber % 10 < 5 ? 'Standard' : roomNumber % 10 < 8 ? 'Deluxe' : 'Suite',
      status: randomStatus,
      guest: randomStatus === 'occupied' ? `Guest ${roomNumber}` : null,
      checkOut: randomStatus === 'occupied' ? '11:00 AM' : null,
      notes: randomStatus === 'maintenance' ? 'AC repair needed' : null
    };
  });

  const housekeepingTasks = [
    {
      id: 'HK001',
      room: '205',
      type: 'Checkout Cleaning',
      assignee: 'Maria Garcia',
      priority: 'high',
      estimatedTime: '45 min',
      status: 'in-progress',
      startTime: '09:30 AM'
    },
    {
      id: 'HK002',
      room: '312',
      type: 'Deep Clean',
      assignee: 'James Wilson',
      priority: 'medium',
      estimatedTime: '90 min',
      status: 'pending',
      startTime: '10:00 AM'
    },
    {
      id: 'HK003',
      room: '108',
      type: 'Maintenance Clean',
      assignee: 'Lisa Chen',
      priority: 'low',
      estimatedTime: '60 min',
      status: 'completed',
      startTime: '08:00 AM'
    },
    {
      id: 'HK004',
      room: '407',
      type: 'Inspection',
      assignee: 'David Brown',
      priority: 'high',
      estimatedTime: '30 min',
      status: 'pending',
      startTime: '11:00 AM'
    }
  ];

  const maintenanceTasks = [
    {
      id: 'MT001',
      room: '302',
      issue: 'Air conditioning not working',
      technician: 'Mike Johnson',
      priority: 'urgent',
      status: 'assigned',
      reportedAt: '08:45 AM',
      estimatedFix: '2 hours'
    },
    {
      id: 'MT002',
      room: '115',
      issue: 'Bathroom faucet leaking',
      technician: 'Sarah Davis',
      priority: 'medium',
      status: 'in-progress',
      reportedAt: '07:30 AM',
      estimatedFix: '1 hour'
    },
    {
      id: 'MT003',
      room: '223',
      issue: 'TV remote not working',
      technician: 'Tom Wilson',
      priority: 'low',
      status: 'completed',
      reportedAt: '09:15 AM',
      estimatedFix: '15 min'
    }
  ];

  const getRoomStatusColor = (status: string) => {
    return roomStatuses[status as keyof typeof roomStatuses]?.color || 'bg-gray-500';
  };

  const getStatusLabel = (status: string) => {
    return roomStatuses[status as keyof typeof roomStatuses]?.label || status;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Room & Housekeeping Management</h1>
          <p className="text-muted-foreground">Monitor room status and manage housekeeping operations</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline">Room Report</Button>
          <Button className="bg-hotel-gold hover:bg-hotel-gold/90 text-hotel-navy">
            Add Task
          </Button>
        </div>
      </div>

      {/* Status Overview */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {Object.entries(roomStatuses).map(([key, status]) => (
          <Card key={key} className="text-center">
            <CardContent className="p-4">
              <div className={`w-8 h-8 ${status.color} rounded-full mx-auto mb-2`} />
              <div className="text-2xl font-bold">{status.count}</div>
              <div className="text-sm text-muted-foreground">{status.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="floor-map" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="floor-map">Floor Map</TabsTrigger>
          <TabsTrigger value="housekeeping">Housekeeping</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* Floor Map Tab */}
        <TabsContent value="floor-map" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Home className="h-5 w-5" />
                <span>Room Status Map</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[1, 2, 3, 4].map((floor) => (
                  <div key={floor} className="space-y-2">
                    <h3>Floor {floor}</h3>
                    <div className="grid grid-cols-10 gap-1">
                      {rooms
                        .filter(room => room.floor === floor)
                        .slice(0, 35)
                        .map((room) => (
                          <div
                            key={room.number}
                            className={`
                              relative p-2 rounded border-2 cursor-pointer transition-all hover:scale-105
                              ${getRoomStatusColor(room.status)} text-white text-center
                            `}
                            title={`Room ${room.number} - ${getStatusLabel(room.status)}`}
                          >
                            <div className="text-xs font-medium">{room.number}</div>
                            <div className="text-xs opacity-75">{room.type[0]}</div>
                            {room.guest && (
                              <div className="absolute top-0 right-0 w-2 h-2 bg-white rounded-full" />
                            )}
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card>
            <CardHeader>
              <CardTitle>Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {Object.entries(roomStatuses).map(([key, status]) => (
                  <div key={key} className="flex items-center space-x-2">
                    <div className={`w-4 h-4 ${status.color} rounded`} />
                    <span className="text-sm">{status.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Housekeeping Tab */}
        <TabsContent value="housekeeping" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>Today's Tasks</span>
                  <Badge variant="secondary">{housekeepingTasks.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {housekeepingTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4>Room {task.room}</h4>
                        <Badge
                          variant={task.priority === 'high' ? 'destructive' : task.priority === 'medium' ? 'default' : 'secondary'}
                        >
                          {task.priority}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            task.status === 'completed' ? 'bg-green-100 text-green-700' :
                            task.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                            'bg-gray-100 text-gray-700'
                          }
                        >
                          {task.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{task.type} • {task.assignee}</p>
                      <p className="text-xs text-muted-foreground">
                        Start: {task.startTime} • Duration: {task.estimatedTime}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {task.status === 'pending' && (
                        <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                          Start Task
                        </Button>
                      )}
                      {task.status === 'in-progress' && (
                        <Button size="sm" className="bg-green-600 hover:bg-green-700">
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Complete
                        </Button>
                      )}
                      {task.status === 'completed' && (
                        <Badge className="bg-green-100 text-green-700">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Done
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Team Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {['Maria Garcia', 'James Wilson', 'Lisa Chen', 'David Brown'].map((staff, index) => (
                  <div key={staff} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="text-sm font-medium">{staff}</h4>
                      <p className="text-xs text-muted-foreground">
                        {index === 0 ? 'Room 205 (In Progress)' : 
                         index === 1 ? 'Available' :
                         index === 2 ? 'Break' :
                         'Room 407 (Starting)'}
                      </p>
                    </div>
                    <div className={`w-2 h-2 rounded-full ${
                      index === 0 ? 'bg-blue-500' :
                      index === 1 ? 'bg-green-500' :
                      index === 2 ? 'bg-yellow-500' :
                      'bg-orange-500'
                    }`} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Maintenance Tab */}
        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Wrench className="h-5 w-5" />
                <span>Maintenance Requests</span>
                <Badge variant="destructive">{maintenanceTasks.filter(t => t.priority === 'urgent').length} Urgent</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {maintenanceTasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h4>Room {task.room}</h4>
                      <Badge
                        variant={task.priority === 'urgent' ? 'destructive' : task.priority === 'medium' ? 'default' : 'secondary'}
                      >
                        {task.priority}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={
                          task.status === 'completed' ? 'bg-green-100 text-green-700' :
                          task.status === 'in-progress' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-700'
                        }
                      >
                        {task.status}
                      </Badge>
                    </div>
                    <p className="text-sm">{task.issue}</p>
                    <p className="text-xs text-muted-foreground">
                      {task.technician} • Reported: {task.reportedAt} • ETA: {task.estimatedFix}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {task.status === 'assigned' && (
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        Start Work
                      </Button>
                    )}
                    {task.status === 'in-progress' && (
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Complete
                      </Button>
                    )}
                    {task.priority === 'urgent' && (
                      <AlertCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Housekeeping Performance</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Tasks Completed Today</span>
                    <span className="font-medium">18/25</span>
                  </div>
                  <Progress value={72} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Average Cleaning Time</span>
                    <span className="font-medium">42 min</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Quality Score</span>
                    <span className="font-medium">4.8/5</span>
                  </div>
                  <Progress value={96} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Maintenance Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-red-600">3</div>
                    <div className="text-sm text-muted-foreground">Urgent</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">5</div>
                    <div className="text-sm text-muted-foreground">Medium</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-green-600">12</div>
                    <div className="text-sm text-muted-foreground">Completed</div>
                  </div>
                  <div className="text-center p-3 border rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">2.5h</div>
                    <div className="text-sm text-muted-foreground">Avg Resolution</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}