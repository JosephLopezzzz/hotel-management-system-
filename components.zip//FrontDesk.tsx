import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Search, UserCheck, UserX, Calendar as CalendarIcon, Key, CreditCard } from "lucide-react";
import { useState } from "react";

export function FrontDesk() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const reservations = [
    {
      id: "RES001",
      guest: "John Smith",
      room: "205",
      checkIn: "2025-08-24",
      checkOut: "2025-08-26",
      status: "confirmed",
      nights: 2,
      amount: "$350"
    },
    {
      id: "RES002",
      guest: "Sarah Johnson",
      room: "312",
      checkIn: "2025-08-24",
      checkOut: "2025-08-25",
      status: "checked-in",
      nights: 1,
      amount: "$180"
    },
    {
      id: "RES003",
      guest: "Mike Davis",
      room: "108",
      checkIn: "2025-08-25",
      checkOut: "2025-08-28",
      status: "pending",
      nights: 3,
      amount: "$540"
    }
  ];

  const checkInQueue = [
    {
      id: "CI001",
      guest: "Emily Brown",
      room: "405",
      time: "14:30",
      vip: true,
      requests: "Late checkout requested"
    },
    {
      id: "CI002",
      guest: "David Wilson",
      room: "201",
      time: "15:00",
      vip: false,
      requests: "Extra towels"
    }
  ];

  const checkOutQueue = [
    {
      id: "CO001",
      guest: "Lisa Chen",
      room: "308",
      time: "11:00",
      bill: "$245.50",
      settled: false
    },
    {
      id: "CO002",
      guest: "Robert Taylor",
      room: "112",
      time: "10:30",
      bill: "$189.00",
      settled: true
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Front Desk Operations</h1>
          <p className="text-muted-foreground">Manage check-ins, check-outs, and reservations</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input placeholder="Search guest..." className="pl-10 w-64" />
          </div>
          <Button className="bg-hotel-gold hover:bg-hotel-gold/90 text-hotel-navy">
            New Reservation
          </Button>
        </div>
      </div>

      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="checkin">Check-in</TabsTrigger>
          <TabsTrigger value="checkout">Check-out</TabsTrigger>
          <TabsTrigger value="reservations">Reservations</TabsTrigger>
        </TabsList>

        {/* Dashboard Tab */}
        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Check-in Queue */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <UserCheck className="h-5 w-5 text-green-600" />
                  <span>Check-in Queue</span>
                  <Badge variant="secondary">{checkInQueue.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {checkInQueue.map((guest) => (
                  <div key={guest.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4>{guest.guest}</h4>
                        {guest.vip && (
                          <Badge className="bg-hotel-gold text-hotel-navy">VIP</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">Room {guest.room} • {guest.time}</p>
                      <p className="text-xs text-muted-foreground">{guest.requests}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button size="sm" variant="outline">
                        <Key className="h-4 w-4 mr-1" />
                        Issue Key
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Check In
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Check-out Queue */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <UserX className="h-5 w-5 text-blue-600" />
                  <span>Check-out Queue</span>
                  <Badge variant="secondary">{checkOutQueue.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {checkOutQueue.map((guest) => (
                  <div key={guest.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h4>{guest.guest}</h4>
                      <p className="text-sm text-muted-foreground">Room {guest.room} • {guest.time}</p>
                      <p className="text-sm font-medium">Bill: {guest.bill}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      {guest.settled ? (
                        <Badge className="bg-green-100 text-green-700">Settled</Badge>
                      ) : (
                        <Button size="sm" variant="outline">
                          <CreditCard className="h-4 w-4 mr-1" />
                          Settle Bill
                        </Button>
                      )}
                      <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                        Check Out
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Check-in Tab */}
        <TabsContent value="checkin" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Guest Check-in</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label>Guest Name</label>
                    <Input placeholder="Enter guest name..." />
                  </div>
                  <div>
                    <label>Reservation ID</label>
                    <Input placeholder="RES001" />
                  </div>
                  <div>
                    <label>Room Assignment</label>
                    <Input placeholder="205" />
                  </div>
                  <div>
                    <label>ID Verification</label>
                    <Button variant="outline" className="w-full">
                      Upload ID Document
                    </Button>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label>Check-in Date</label>
                    <Input type="date" defaultValue="2025-08-24" />
                  </div>
                  <div>
                    <label>Check-out Date</label>
                    <Input type="date" defaultValue="2025-08-26" />
                  </div>
                  <div>
                    <label>Number of Guests</label>
                    <Input type="number" defaultValue="2" />
                  </div>
                  <div>
                    <label>Special Requests</label>
                    <Input placeholder="Enter any special requests..." />
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-4">
                <Button variant="outline">Cancel</Button>
                <Button className="bg-green-600 hover:bg-green-700">
                  Complete Check-in
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Check-out Tab */}
        <TabsContent value="checkout" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Guest Check-out</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label>Room Number</label>
                    <Input placeholder="Enter room number..." />
                  </div>
                  <div>
                    <label>Guest Name</label>
                    <Input placeholder="Auto-filled from room..." disabled />
                  </div>
                  <div className="p-4 border rounded-lg bg-muted/50">
                    <h4 className="mb-2">Bill Summary</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Room charges (2 nights)</span>
                        <span>$300.00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Restaurant</span>
                        <span>$45.50</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Minibar</span>
                        <span>$15.00</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tax</span>
                        <span>$36.05</span>
                      </div>
                      <div className="flex justify-between font-medium border-t pt-1">
                        <span>Total</span>
                        <span>$396.55</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <label>Payment Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline">Cash</Button>
                      <Button variant="outline">Card</Button>
                      <Button variant="outline">Digital Wallet</Button>
                      <Button variant="outline">Bank Transfer</Button>
                    </div>
                  </div>
                  <div>
                    <label>Feedback Rating</label>
                    <div className="flex space-x-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Button key={star} variant="outline" size="sm">
                          ⭐
                        </Button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label>Additional Notes</label>
                    <Input placeholder="Any checkout notes..." />
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-4">
                <Button variant="outline">Print Receipt</Button>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Complete Check-out
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reservations Tab */}
        <TabsContent value="reservations" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Today's Reservations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reservations.map((reservation) => (
                    <div key={reservation.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4>{reservation.guest}</h4>
                          <Badge
                            variant={
                              reservation.status === "confirmed" ? "secondary" :
                              reservation.status === "checked-in" ? "default" : "outline"
                            }
                            className={
                              reservation.status === "checked-in" ? "bg-green-100 text-green-700" : ""
                            }
                          >
                            {reservation.status}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Room {reservation.room} • {reservation.nights} nights • {reservation.amount}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {reservation.checkIn} to {reservation.checkOut}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button size="sm" variant="outline">Edit</Button>
                        <Button size="sm" variant="outline">Cancel</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CalendarIcon className="h-5 w-5" />
                  <span>Calendar</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}