<div class="space-y-6">
    <div>
        <h1>Analytics & Reporting</h1>
        <p class="text-muted">Comprehensive business intelligence and reports</p>
    </div>
    <div class="grid grid-cols-1 grid-cols-2 grid-cols-3 gap-6">
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="bar-chart-3" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Revenue Analytics</h3>
            <p class="text-sm">Track revenue trends and forecasts</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="users" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Guest Demographics</h3>
            <p class="text-sm">Analyze guest patterns and preferences</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="home" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Occupancy Reports</h3>
            <p class="text-sm">Monitor room utilization and trends</p>
        </div>
    </div>
</div>