<?php
$reservations = [
    [
        'id' => 'RES001',
        'guest' => 'John Smith',
        'room' => '205',
        'checkIn' => '2025-08-24',
        'checkOut' => '2025-08-26',
        'status' => 'confirmed',
        'nights' => 2,
        'amount' => '$350'
    ],
    [
        'id' => 'RES002',
        'guest' => 'Sarah Johnson',
        'room' => '312',
        'checkIn' => '2025-08-24',
        'checkOut' => '2025-08-25',
        'status' => 'checked-in',
        'nights' => 1,
        'amount' => '$180'
    ],
    [
        'id' => 'RES003',
        'guest' => 'Mike Davis',
        'room' => '108',
        'checkIn' => '2025-08-25',
        'checkOut' => '2025-08-28',
        'status' => 'pending',
        'nights' => 3,
        'amount' => '$540'
    ]
];

$checkInQueue = [
    [
        'id' => 'CI001',
        'guest' => 'Emily Brown',
        'room' => '405',
        'time' => '14:30',
        'vip' => true,
        'requests' => 'Late checkout requested'
    ],
    [
        'id' => 'CI002',
        'guest' => 'David Wilson',
        'room' => '201',
        'time' => '15:00',
        'vip' => false,
        'requests' => 'Extra towels'
    ]
];

$checkOutQueue = [
    [
        'id' => 'CO001',
        'guest' => 'Lisa Chen',
        'room' => '308',
        'time' => '11:00',
        'bill' => '$245.50',
        'settled' => false
    ],
    [
        'id' => 'CO002',
        'guest' => 'Robert Taylor',
        'room' => '112',
        'time' => '10:30',
        'bill' => '$189.00',
        'settled' => true
    ]
];
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1>Front Desk Operations</h1>
            <p class="text-muted">Manage check-ins, check-outs, and reservations</p>
        </div>
        <div class="flex items-center gap-2">
            <div class="relative">
                <input type="text" placeholder="Search guest..." class="form-input pl-10" style="width: 250px;">
                <i data-lucide="search" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted"></i>
            </div>
            <button class="btn btn-gold">
                New Reservation
            </button>
        </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
        <div class="tab-list">
            <button class="tab-trigger" data-tab="dashboard">Dashboard</button>
            <button class="tab-trigger" data-tab="checkin">Check-in</button>
            <button class="tab-trigger" data-tab="checkout">Check-out</button>
            <button class="tab-trigger" data-tab="reservations">Reservations</button>
        </div>

        <!-- Dashboard Tab -->
        <div id="dashboard" class="tab-content">
            <div class="grid grid-cols-1 grid-cols-2 gap-6">
                <!-- Check-in Queue -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i data-lucide="user-check" class="text-green-600"></i>
                            Check-in Queue
                            <span class="badge badge-secondary"><?= count($checkInQueue) ?></span>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <?php foreach ($checkInQueue as $guest): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <h4><?= htmlspecialchars($guest['guest']) ?></h4>
                                            <?php if ($guest['vip']): ?>
                                                <span class="badge btn-gold">VIP</span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="text-sm text-muted">Room <?= $guest['room'] ?> • <?= $guest['time'] ?></p>
                                        <p class="text-xs text-muted"><?= htmlspecialchars($guest['requests']) ?></p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button class="btn btn-sm btn-outline">
                                            <i data-lucide="key" class="mr-1"></i>
                                            Issue Key
                                        </button>
                                        <button class="btn btn-sm btn-success">
                                            Check In
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Check-out Queue -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i data-lucide="user-x" class="text-blue-600"></i>
                            Check-out Queue
                            <span class="badge badge-secondary"><?= count($checkOutQueue) ?></span>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <?php foreach ($checkOutQueue as $guest): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg">
                                    <div class="flex-1">
                                        <h4><?= htmlspecialchars($guest['guest']) ?></h4>
                                        <p class="text-sm text-muted">Room <?= $guest['room'] ?> • <?= $guest['time'] ?></p>
                                        <p class="text-sm font-semibold">Bill: <?= $guest['bill'] ?></p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <?php if ($guest['settled']): ?>
                                            <span class="badge bg-green-50 text-green-600">Settled</span>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-outline">
                                                <i data-lucide="credit-card" class="mr-1"></i>
                                                Settle Bill
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-sm btn-primary">
                                            Check Out
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Check-in Tab -->
        <div id="checkin" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Guest Check-in</h3>
                </div>
                <div class="card-content">
                    <form id="checkin-form" class="space-y-6">
                        <div class="grid grid-cols-1 grid-cols-2 gap-6">
                            <div class="space-y-4">
                                <div class="form-group">
                                    <label class="form-label">Guest Name</label>
                                    <input type="text" class="form-input" placeholder="Enter guest name..." required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Reservation ID</label>
                                    <input type="text" class="form-input" placeholder="RES001">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Room Assignment</label>
                                    <input type="text" class="form-input" placeholder="205">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">ID Verification</label>
                                    <button type="button" class="btn btn-outline w-full">
                                        Upload ID Document
                                    </button>
                                </div>
                            </div>
                            <div class="space-y-4">
                                <div class="form-group">
                                    <label class="form-label">Check-in Date</label>
                                    <input type="date" class="form-input" value="2025-08-24">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Check-out Date</label>
                                    <input type="date" class="form-input" value="2025-08-26">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Number of Guests</label>
                                    <input type="number" class="form-input" value="2">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Special Requests</label>
                                    <input type="text" class="form-input" placeholder="Enter any special requests...">
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-end gap-4">
                            <button type="button" class="btn btn-outline">Cancel</button>
                            <button type="submit" class="btn btn-success">
                                Complete Check-in
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Check-out Tab -->
        <div id="checkout" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Guest Check-out</h3>
                </div>
                <div class="card-content">
                    <form id="checkout-form" class="space-y-6">
                        <div class="grid grid-cols-1 grid-cols-2 gap-6">
                            <div class="space-y-4">
                                <div class="form-group">
                                    <label class="form-label">Room Number</label>
                                    <input type="text" class="form-input" placeholder="Enter room number...">
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Guest Name</label>
                                    <input type="text" class="form-input" placeholder="Auto-filled from room..." disabled>
                                </div>
                                <div class="p-4 border rounded-lg bg-muted">
                                    <h4 class="mb-2">Bill Summary</h4>
                                    <div class="space-y-1 text-sm">
                                        <div class="flex justify-between">
                                            <span>Room charges (2 nights)</span>
                                            <span>$300.00</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span>Restaurant</span>
                                            <span>$45.50</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span>Minibar</span>
                                            <span>$15.00</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span>Tax</span>
                                            <span>$36.05</span>
                                        </div>
                                        <div class="flex justify-between font-semibold border-t pt-1">
                                            <span>Total</span>
                                            <span>$396.55</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="space-y-4">
                                <div class="form-group">
                                    <label class="form-label">Payment Method</label>
                                    <div class="grid grid-cols-2 gap-2">
                                        <button type="button" class="btn btn-outline">Cash</button>
                                        <button type="button" class="btn btn-outline">Card</button>
                                        <button type="button" class="btn btn-outline">Digital Wallet</button>
                                        <button type="button" class="btn btn-outline">Bank Transfer</button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Feedback Rating</label>
                                    <div class="flex gap-1">
                                        <button type="button" class="btn btn-sm btn-outline">⭐</button>
                                        <button type="button" class="btn btn-sm btn-outline">⭐</button>
                                        <button type="button" class="btn btn-sm btn-outline">⭐</button>
                                        <button type="button" class="btn btn-sm btn-outline">⭐</button>
                                        <button type="button" class="btn btn-sm btn-outline">⭐</button>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label">Additional Notes</label>
                                    <input type="text" class="form-input" placeholder="Any checkout notes...">
                                </div>
                            </div>
                        </div>
                        <div class="flex justify-end gap-4">
                            <button type="button" class="btn btn-outline">Print Receipt</button>
                            <button type="submit" class="btn btn-primary">
                                Complete Check-out
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Reservations Tab -->
        <div id="reservations" class="tab-content">
            <div class="grid grid-cols-1 grid-cols-3 gap-6">
                <div class="card" style="grid-column: span 2;">
                    <div class="card-header">
                        <h3 class="card-title">Today's Reservations</h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <?php foreach ($reservations as $reservation): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <h4><?= htmlspecialchars($reservation['guest']) ?></h4>
                                            <span class="badge <?= 
                                                $reservation['status'] === 'confirmed' ? 'badge-secondary' :
                                                ($reservation['status'] === 'checked-in' ? 'bg-green-50 text-green-600' : 'btn-outline')
                                            ?>">
                                                <?= htmlspecialchars($reservation['status']) ?>
                                            </span>
                                        </div>
                                        <p class="text-sm text-muted">
                                            Room <?= $reservation['room'] ?> • <?= $reservation['nights'] ?> nights • <?= $reservation['amount'] ?>
                                        </p>
                                        <p class="text-xs text-muted">
                                            <?= $reservation['checkIn'] ?> to <?= $reservation['checkOut'] ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button class="btn btn-sm btn-outline">Edit</button>
                                        <button class="btn btn-sm btn-outline">Cancel</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i data-lucide="calendar"></i>
                            Calendar
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="text-center p-4 border rounded-lg">
                            <i data-lucide="calendar" class="mb-2"></i>
                            <p class="text-sm text-muted">Calendar widget would go here</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form submission handlers
    document.getElementById('checkin-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        if (validateForm('checkin-form')) {
            showToast('Guest checked in successfully!', 'success');
        } else {
            showToast('Please fill in all required fields', 'error');
        }
    });

    document.getElementById('checkout-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        showToast('Guest checked out successfully!', 'success');
    });
});
</script>