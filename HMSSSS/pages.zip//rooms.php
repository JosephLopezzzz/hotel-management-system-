<?php
$roomStatuses = [
    'vacant' => ['count' => 25, 'color' => 'status-vacant', 'label' => 'Vacant Clean'],
    'occupied' => ['count' => 85, 'color' => 'status-occupied', 'label' => 'Occupied'],
    'dirty' => ['count' => 15, 'color' => 'status-dirty', 'label' => 'Vacant Dirty'],
    'maintenance' => ['count' => 8, 'color' => 'status-maintenance', 'label' => 'Out of Order'],
    'cleaning' => ['count' => 7, 'color' => 'status-cleaning', 'label' => 'Being Cleaned']
];

// Generate room data
$rooms = [];
$statuses = array_keys($roomStatuses);
for ($i = 101; $i <= 440; $i++) {
    $floor = floor($i / 100);
    $randomStatus = $statuses[array_rand($statuses)];
    $type = ($i % 10 < 5) ? 'S' : (($i % 10 < 8) ? 'D' : 'T'); // Standard, Deluxe, Suite
    
    $rooms[] = [
        'number' => $i,
        'floor' => $floor,
        'type' => $type,
        'status' => $randomStatus,
        'guest' => ($randomStatus === 'occupied') ? "Guest $i" : null
    ];
}

$housekeepingTasks = [
    [
        'id' => 'HK001',
        'room' => '205',
        'type' => 'Checkout Cleaning',
        'assignee' => 'Maria Garcia',
        'priority' => 'high',
        'estimatedTime' => '45 min',
        'status' => 'in-progress',
        'startTime' => '09:30 AM'
    ],
    [
        'id' => 'HK002',
        'room' => '312',
        'type' => 'Deep Clean',
        'assignee' => 'James Wilson',
        'priority' => 'medium',
        'estimatedTime' => '90 min',
        'status' => 'pending',
        'startTime' => '10:00 AM'
    ],
    [
        'id' => 'HK003',
        'room' => '108',
        'type' => 'Maintenance Clean',
        'assignee' => 'Lisa Chen',
        'priority' => 'low',
        'estimatedTime' => '60 min',
        'status' => 'completed',
        'startTime' => '08:00 AM'
    ],
    [
        'id' => 'HK004',
        'room' => '407',
        'type' => 'Inspection',
        'assignee' => 'David Brown',
        'priority' => 'high',
        'estimatedTime' => '30 min',
        'status' => 'pending',
        'startTime' => '11:00 AM'
    ]
];

$maintenanceTasks = [
    [
        'id' => 'MT001',
        'room' => '302',
        'issue' => 'Air conditioning not working',
        'technician' => 'Mike Johnson',
        'priority' => 'urgent',
        'status' => 'assigned',
        'reportedAt' => '08:45 AM',
        'estimatedFix' => '2 hours'
    ],
    [
        'id' => 'MT002',
        'room' => '115',
        'issue' => 'Bathroom faucet leaking',
        'technician' => 'Sarah Davis',
        'priority' => 'medium',
        'status' => 'in-progress',
        'reportedAt' => '07:30 AM',
        'estimatedFix' => '1 hour'
    ],
    [
        'id' => 'MT003',
        'room' => '223',
        'issue' => 'TV remote not working',
        'technician' => 'Tom Wilson',
        'priority' => 'low',
        'status' => 'completed',
        'reportedAt' => '09:15 AM',
        'estimatedFix' => '15 min'
    ]
];

$staff = [
    ['name' => 'Maria Garcia', 'status' => 'Room 205 (In Progress)', 'indicator' => 'bg-blue-500'],
    ['name' => 'James Wilson', 'status' => 'Available', 'indicator' => 'bg-green-500'],
    ['name' => 'Lisa Chen', 'status' => 'Break', 'indicator' => 'bg-yellow-500'],
    ['name' => 'David Brown', 'status' => 'Room 407 (Starting)', 'indicator' => 'bg-orange-500']
];
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1>Room & Housekeeping Management</h1>
            <p class="text-muted">Monitor room status and manage housekeeping operations</p>
        </div>
        <div class="flex items-center gap-2">
            <button class="btn btn-outline">Room Report</button>
            <button class="btn btn-gold">
                Add Task
            </button>
        </div>
    </div>

    <!-- Status Overview -->
    <div class="grid grid-cols-2 grid-cols-5 gap-4">
        <?php foreach ($roomStatuses as $key => $status): ?>
            <div class="card text-center">
                <div class="card-content p-4">
                    <div class="w-8 h-8 <?= $status['color'] ?> rounded-full mx-auto mb-2"></div>
                    <div class="text-2xl font-bold"><?= $status['count'] ?></div>
                    <div class="text-sm text-muted"><?= $status['label'] ?></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- Tabs -->
    <div class="tabs">
        <div class="tab-list">
            <button class="tab-trigger" data-tab="floor-map">Floor Map</button>
            <button class="tab-trigger" data-tab="housekeeping">Housekeeping</button>
            <button class="tab-trigger" data-tab="maintenance">Maintenance</button>
            <button class="tab-trigger" data-tab="reports">Reports</button>
        </div>

        <!-- Floor Map Tab -->
        <div id="floor-map" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i data-lucide="home"></i>
                        Room Status Map
                    </h3>
                </div>
                <div class="card-content">
                    <div class="space-y-6">
                        <?php for ($floor = 1; $floor <= 4; $floor++): ?>
                            <div class="space-y-2">
                                <h3>Floor <?= $floor ?></h3>
                                <div class="room-grid">
                                    <?php 
                                    $floorRooms = array_filter($rooms, function($room) use ($floor) {
                                        return $room['floor'] === $floor;
                                    });
                                    $floorRooms = array_slice($floorRooms, 0, 35);
                                    ?>
                                    <?php foreach ($floorRooms as $room): ?>
                                        <div class="room-item <?= $roomStatuses[$room['status']]['color'] ?>" 
                                             data-room="<?= $room['number'] ?>" 
                                             data-status="<?= $room['status'] ?>"
                                             title="Room <?= $room['number'] ?> - <?= $roomStatuses[$room['status']]['label'] ?>">
                                            <div class="room-number"><?= $room['number'] ?></div>
                                            <div class="room-type"><?= $room['type'] ?></div>
                                            <?php if ($room['guest']): ?>
                                                <div class="room-guest-indicator"></div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>

            <!-- Legend -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Legend</h3>
                </div>
                <div class="card-content">
                    <div class="grid grid-cols-2 grid-cols-5 gap-4">
                        <?php foreach ($roomStatuses as $key => $status): ?>
                            <div class="flex items-center gap-2">
                                <div class="w-4 h-4 <?= $status['color'] ?> rounded"></div>
                                <span class="text-sm"><?= $status['label'] ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Housekeeping Tab -->
        <div id="housekeeping" class="tab-content">
            <div class="grid grid-cols-1 grid-cols-3 gap-6">
                <div class="card" style="grid-column: span 2;">
                    <div class="card-header">
                        <h3 class="card-title">
                            <i data-lucide="users"></i>
                            Today's Tasks
                            <span class="badge badge-secondary"><?= count($housekeepingTasks) ?></span>
                        </h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <?php foreach ($housekeepingTasks as $task): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <h4>Room <?= htmlspecialchars($task['room']) ?></h4>
                                            <span class="badge <?= 
                                                $task['priority'] === 'high' ? 'btn-danger' : 
                                                ($task['priority'] === 'medium' ? 'badge-secondary' : 'badge-secondary')
                                            ?>">
                                                <?= htmlspecialchars($task['priority']) ?>
                                            </span>
                                            <span class="badge <?= 
                                                $task['status'] === 'completed' ? 'bg-green-50 text-green-600' :
                                                ($task['status'] === 'in-progress' ? 'bg-blue-50 text-blue-600' : 'badge-secondary')
                                            ?>">
                                                <?= htmlspecialchars($task['status']) ?>
                                            </span>
                                        </div>
                                        <p class="text-sm text-muted"><?= htmlspecialchars($task['type']) ?> • <?= htmlspecialchars($task['assignee']) ?></p>
                                        <p class="text-xs text-muted">
                                            Start: <?= $task['startTime'] ?> • Duration: <?= $task['estimatedTime'] ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <?php if ($task['status'] === 'pending'): ?>
                                            <button class="btn btn-sm btn-primary">Start Task</button>
                                        <?php elseif ($task['status'] === 'in-progress'): ?>
                                            <button class="btn btn-sm btn-success">
                                                <i data-lucide="check-circle" class="mr-1"></i>
                                                Complete
                                            </button>
                                        <?php else: ?>
                                            <span class="badge bg-green-50 text-green-600">
                                                <i data-lucide="check-circle" class="mr-1"></i>
                                                Done
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Team Status</h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <?php foreach ($staff as $member): ?>
                                <div class="flex items-center justify-between p-3 border rounded-lg">
                                    <div>
                                        <h4 class="text-sm font-semibold"><?= htmlspecialchars($member['name']) ?></h4>
                                        <p class="text-xs text-muted"><?= htmlspecialchars($member['status']) ?></p>
                                    </div>
                                    <div class="w-2 h-2 rounded-full <?= $member['indicator'] ?>"></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Maintenance Tab -->
        <div id="maintenance" class="tab-content">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i data-lucide="wrench"></i>
                        Maintenance Requests
                        <span class="badge btn-danger"><?= count(array_filter($maintenanceTasks, function($t) { return $t['priority'] === 'urgent'; })) ?> Urgent</span>
                    </h3>
                </div>
                <div class="card-content">
                    <div class="space-y-4">
                        <?php foreach ($maintenanceTasks as $task): ?>
                            <div class="flex items-center justify-between p-4 border rounded-lg">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <h4>Room <?= htmlspecialchars($task['room']) ?></h4>
                                        <span class="badge <?= 
                                            $task['priority'] === 'urgent' ? 'btn-danger' : 
                                            ($task['priority'] === 'medium' ? 'badge-secondary' : 'badge-secondary')
                                        ?>">
                                            <?= htmlspecialchars($task['priority']) ?>
                                        </span>
                                        <span class="badge <?= 
                                            $task['status'] === 'completed' ? 'bg-green-50 text-green-600' :
                                            ($task['status'] === 'in-progress' ? 'bg-blue-50 text-blue-600' : 'badge-secondary')
                                        ?>">
                                            <?= htmlspecialchars($task['status']) ?>
                                        </span>
                                    </div>
                                    <p class="text-sm"><?= htmlspecialchars($task['issue']) ?></p>
                                    <p class="text-xs text-muted">
                                        <?= htmlspecialchars($task['technician']) ?> • Reported: <?= $task['reportedAt'] ?> • ETA: <?= $task['estimatedFix'] ?>
                                    </p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <?php if ($task['status'] === 'assigned'): ?>
                                        <button class="btn btn-sm btn-primary">Start Work</button>
                                    <?php elseif ($task['status'] === 'in-progress'): ?>
                                        <button class="btn btn-sm btn-success">Complete</button>
                                    <?php endif; ?>
                                    <?php if ($task['priority'] === 'urgent'): ?>
                                        <i data-lucide="alert-circle" class="text-red-500"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Reports Tab -->
        <div id="reports" class="tab-content">
            <div class="grid grid-cols-1 grid-cols-2 gap-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Housekeeping Performance</h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span>Tasks Completed Today</span>
                                    <span class="font-semibold">18/25</span>
                                </div>
                                <div class="progress" data-value="72">
                                    <div class="progress-bar"></div>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span>Average Cleaning Time</span>
                                    <span class="font-semibold">42 min</span>
                                </div>
                                <div class="progress" data-value="85">
                                    <div class="progress-bar"></div>
                                </div>
                            </div>
                            <div class="space-y-2">
                                <div class="flex justify-between">
                                    <span>Quality Score</span>
                                    <span class="font-semibold">4.8/5</span>
                                </div>
                                <div class="progress" data-value="96">
                                    <div class="progress-bar"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Maintenance Summary</h3>
                    </div>
                    <div class="card-content">
                        <div class="space-y-4">
                            <div class="grid grid-cols-2 gap-4">
                                <div class="text-center p-3 border rounded-lg">
                                    <div class="text-2xl font-bold text-red-600">3</div>
                                    <div class="text-sm text-muted">Urgent</div>
                                </div>
                                <div class="text-center p-3 border rounded-lg">
                                    <div class="text-2xl font-bold text-yellow-600">5</div>
                                    <div class="text-sm text-muted">Medium</div>
                                </div>
                                <div class="text-center p-3 border rounded-lg">
                                    <div class="text-2xl font-bold text-green-600">12</div>
                                    <div class="text-sm text-muted">Completed</div>
                                </div>
                                <div class="text-center p-3 border rounded-lg">
                                    <div class="text-2xl font-bold text-blue-600">2.5h</div>
                                    <div class="text-sm text-muted">Avg Resolution</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>