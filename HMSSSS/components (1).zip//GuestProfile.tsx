import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Progress } from "./ui/progress";
import { User, Star, Heart, Gift, Calendar, Phone, Mail, MapPin } from "lucide-react";

export function GuestProfile() {
  const guestProfile = {
    id: "GUEST001",
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    phone: "+1 (555) 123-4567",
    address: "123 Main St, New York, NY 10001",
    loyaltyTier: "Gold",
    loyaltyPoints: 2450,
    totalStays: 12,
    totalSpent: "$4,850",
    averageRating: 4.8,
    joinDate: "2023-03-15",
    lastStay: "2025-07-15",
    preferences: {
      roomType: "King Suite",
      floor: "High floor",
      view: "Ocean view",
      temperature: "72°F",
      pillow: "Soft",
      dietary: "Vegetarian"
    },
    specialRequests: [
      "Late checkout when available",
      "Extra towels",
      "Room service breakfast at 8 AM"
    ]
  };

  const stayHistory = [
    {
      id: "STAY001",
      dates: "Jul 15-17, 2025",
      room: "308",
      nights: 2,
      amount: "$420",
      rating: 5,
      status: "completed"
    },
    {
      id: "STAY002",
      dates: "May 22-25, 2025",
      room: "205",
      nights: 3,
      amount: "$630",
      rating: 4,
      status: "completed"
    },
    {
      id: "STAY003",
      dates: "Mar 10-12, 2025",
      room: "412",
      nights: 2,
      amount: "$380",
      rating: 5,
      status: "completed"
    }
  ];

  const upcomingReservations = [
    {
      id: "RES001",
      dates: "Sep 15-18, 2025",
      room: "Suite 501",
      nights: 3,
      amount: "$750",
      status: "confirmed"
    }
  ];

  const loyaltyProgress = (guestProfile.loyaltyPoints % 3000) / 3000 * 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Guest Profile & CRM</h1>
          <p className="text-muted-foreground">Manage guest relationships and personalize experiences</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline">Export Profile</Button>
          <Button className="bg-hotel-gold hover:bg-hotel-gold/90 text-hotel-navy">
            New Marketing Campaign
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Guest Profile Card */}
        <Card className="lg:col-span-1">
          <CardHeader className="text-center">
            <Avatar className="w-24 h-24 mx-auto">
              <AvatarImage src="/placeholder-avatar.jpg" alt={guestProfile.name} />
              <AvatarFallback className="text-lg bg-hotel-light-gold text-hotel-navy">
                {guestProfile.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <CardTitle>{guestProfile.name}</CardTitle>
            <div className="flex items-center justify-center space-x-2">
              <Badge className="bg-hotel-gold text-hotel-navy">
                {guestProfile.loyaltyTier}
              </Badge>
              <div className="flex items-center space-x-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm">{guestProfile.averageRating}</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center space-x-2 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span>{guestProfile.email}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span>{guestProfile.phone}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span>{guestProfile.address}</span>
              </div>
            </div>

            {/* Loyalty Progress */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Loyalty Points</span>
                <span className="font-medium">{guestProfile.loyaltyPoints}</span>
              </div>
              <Progress value={loyaltyProgress} className="h-2" />
              <p className="text-xs text-muted-foreground">
                {3000 - (guestProfile.loyaltyPoints % 3000)} points to next tier
              </p>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-hotel-navy">{guestProfile.totalStays}</div>
                <div className="text-xs text-muted-foreground">Total Stays</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{guestProfile.totalSpent}</div>
                <div className="text-xs text-muted-foreground">Total Spent</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Information */}
        <Card className="lg:col-span-2">
          <Tabs defaultValue="preferences" className="w-full">
            <CardHeader>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="preferences">Preferences</TabsTrigger>
                <TabsTrigger value="history">Stay History</TabsTrigger>
                <TabsTrigger value="reservations">Reservations</TabsTrigger>
                <TabsTrigger value="marketing">Marketing</TabsTrigger>
              </TabsList>
            </CardHeader>

            <CardContent>
              {/* Preferences Tab */}
              <TabsContent value="preferences" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4>Room Preferences</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Room Type:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.roomType}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Floor Preference:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.floor}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">View:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.view}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Temperature:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.temperature}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Pillow Type:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.pillow}</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h4>Dining & Special Requests</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Dietary Restrictions:</span>
                        <span className="text-sm font-medium">{guestProfile.preferences.dietary}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h5 className="text-sm font-medium">Special Requests:</h5>
                      {guestProfile.specialRequests.map((request, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-hotel-gold rounded-full" />
                          <span className="text-sm">{request}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline">Edit Preferences</Button>
                  <Button className="bg-hotel-navy hover:bg-hotel-navy/90">Save Changes</Button>
                </div>
              </TabsContent>

              {/* Stay History Tab */}
              <TabsContent value="history" className="space-y-4">
                {stayHistory.map((stay) => (
                  <div key={stay.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h4>{stay.dates}</h4>
                        <Badge variant="outline">Room {stay.room}</Badge>
                        <div className="flex items-center space-x-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${
                                i < stay.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {stay.nights} nights • {stay.amount}
                      </p>
                    </div>
                    <Button variant="outline" size="sm">View Details</Button>
                  </div>
                ))}
              </TabsContent>

              {/* Reservations Tab */}
              <TabsContent value="reservations" className="space-y-4">
                <div className="space-y-4">
                  <h4>Upcoming Reservations</h4>
                  {upcomingReservations.map((reservation) => (
                    <div key={reservation.id} className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4>{reservation.dates}</h4>
                          <Badge className="bg-green-100 text-green-700">{reservation.status}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {reservation.room} • {reservation.nights} nights • {reservation.amount}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">Modify</Button>
                        <Button size="sm" className="bg-hotel-navy">Upgrade</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>

              {/* Marketing Tab */}
              <TabsContent value="marketing" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4>Campaign History</h4>
                    <div className="space-y-2">
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">Summer Special Offer</span>
                          <Badge variant="outline">Opened</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Sent: Aug 10, 2025</p>
                      </div>
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">Loyalty Rewards Update</span>
                          <Badge variant="outline">Clicked</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Sent: Jul 25, 2025</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h4>Recommended Campaigns</h4>
                    <div className="space-y-2">
                      <div className="p-3 border rounded-lg bg-hotel-light-gold/20">
                        <div className="flex items-center space-x-2 mb-1">
                          <Gift className="h-4 w-4 text-hotel-gold" />
                          <span className="font-medium">Birthday Special</span>
                        </div>
                        <p className="text-sm text-muted-foreground">Personalized birthday offer</p>
                        <Button size="sm" variant="outline" className="mt-2">Send Campaign</Button>
                      </div>
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center space-x-2 mb-1">
                          <Heart className="h-4 w-4 text-red-500" />
                          <span className="font-medium">VIP Upgrade Offer</span>
                        </div>
                        <p className="text-sm text-muted-foreground">Exclusive suite upgrade</p>
                        <Button size="sm" variant="outline" className="mt-2">Send Campaign</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </CardContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}