// Hotel Management System JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lucide icons
    lucide.createIcons();
    
    // Initialize tabs
    initializeTabs();
    
    // Initialize any interactive components
    initializeComponents();
});

// Role Management
function changeRole(role) {
    const formData = new FormData();
    formData.append('role', role);
    formData.append('current_page', getCurrentPage());
    
    fetch('change-role.php', {
        method: 'POST',
        body: formData
    }).then(() => {
        window.location.reload();
    });
}

function getCurrentPage() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('page') || 'dashboard';
}

// Sidebar Toggle for Mobile
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('open');
}

// Tab System
function initializeTabs() {
    const tabTriggers = document.querySelectorAll('.tab-trigger');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const target = this.getAttribute('data-tab');
            
            // Remove active class from all triggers and contents
            tabTriggers.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked trigger
            this.classList.add('active');
            
            // Show corresponding content
            const targetContent = document.getElementById(target);
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
    
    // Activate first tab by default
    if (tabTriggers.length > 0) {
        tabTriggers[0].click();
    }
}

// Progress Bar Animation
function animateProgress(element, targetValue) {
    const progressBar = element.querySelector('.progress-bar');
    if (!progressBar) return;
    
    let currentValue = 0;
    const increment = targetValue / 50;
    
    const timer = setInterval(() => {
        currentValue += increment;
        if (currentValue >= targetValue) {
            currentValue = targetValue;
            clearInterval(timer);
        }
        progressBar.style.width = currentValue + '%';
    }, 20);
}

// Initialize all progress bars
function initializeProgressBars() {
    const progressElements = document.querySelectorAll('.progress');
    progressElements.forEach(element => {
        const value = element.getAttribute('data-value') || 0;
        animateProgress(element, parseFloat(value));
    });
}

// Room Status Management
function updateRoomStatus(roomNumber, status) {
    const room = document.querySelector(`[data-room="${roomNumber}"]`);
    if (!room) return;
    
    // Remove all status classes
    room.classList.remove('status-vacant', 'status-occupied', 'status-dirty', 'status-maintenance', 'status-cleaning');
    
    // Add new status class
    room.classList.add(`status-${status}`);
    
    // Update room data
    room.setAttribute('data-status', status);
    
    console.log(`Room ${roomNumber} status updated to ${status}`);
}

// Modal System
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        closeModal(e.target.id);
    }
});

// Toast Notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    // Add to page
    document.body.appendChild(toast);
    
    // Show toast
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// Form Validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('error');
            isValid = false;
        } else {
            field.classList.remove('error');
        }
    });
    
    return isValid;
}

// Search Functionality
function initializeSearch() {
    const searchInputs = document.querySelectorAll('.search-input');
    
    searchInputs.forEach(input => {
        input.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const targetContainer = this.getAttribute('data-search-target');
            const container = document.querySelector(targetContainer);
            
            if (!container) return;
            
            const items = container.querySelectorAll('.searchable-item');
            
            items.forEach(item => {
                const text = item.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
}

// Date and Time Functions
function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    }).format(date);
}

function formatTime(date) {
    return new Intl.DateTimeFormat('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Auto-refresh functions
function startAutoRefresh(interval = 30000) {
    setInterval(() => {
        // Refresh key metrics
        refreshDashboardData();
    }, interval);
}

function refreshDashboardData() {
    // This would typically make AJAX calls to update dashboard data
    console.log('Refreshing dashboard data...');
}

// Drag and Drop for Housekeeping Tasks
function initializeDragAndDrop() {
    const draggableItems = document.querySelectorAll('.draggable');
    const dropZones = document.querySelectorAll('.drop-zone');
    
    draggableItems.forEach(item => {
        item.addEventListener('dragstart', function(e) {
            e.dataTransfer.setData('text/plain', this.id);
            this.classList.add('dragging');
        });
        
        item.addEventListener('dragend', function() {
            this.classList.remove('dragging');
        });
    });
    
    dropZones.forEach(zone => {
        zone.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });
        
        zone.addEventListener('dragleave', function() {
            this.classList.remove('drag-over');
        });
        
        zone.addEventListener('drop', function(e) {
            e.preventDefault();
            const itemId = e.dataTransfer.getData('text/plain');
            const item = document.getElementById(itemId);
            
            if (item) {
                this.appendChild(item);
                this.classList.remove('drag-over');
                
                // Trigger callback
                const callback = this.getAttribute('data-drop-callback');
                if (callback && typeof window[callback] === 'function') {
                    window[callback](itemId, this.id);
                }
            }
        });
    });
}

// Initialize all components
function initializeComponents() {
    initializeProgressBars();
    initializeSearch();
    initializeDragAndDrop();
    
    // Auto-refresh dashboard data every 30 seconds
    if (getCurrentPage() === 'dashboard') {
        startAutoRefresh();
    }
}

// Utility Functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for global use
window.changeRole = changeRole;
window.toggleSidebar = toggleSidebar;
window.updateRoomStatus = updateRoomStatus;
window.openModal = openModal;
window.closeModal = closeModal;
window.showToast = showToast;
window.validateForm = validateForm;