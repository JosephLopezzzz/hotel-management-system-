<div class="space-y-6">
    <div>
        <h1>Channel Management</h1>
        <p class="text-muted">Manage OTA integrations and distribution channels</p>
    </div>
    <div class="grid grid-cols-1 grid-cols-2 grid-cols-3 gap-6">
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="globe" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>OTA Integration</h3>
            <p class="text-sm">Connect with Booking.com, Expedia, Agoda</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="settings" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Rate Management</h3>
            <p class="text-sm">Sync pricing across all channels</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="bar-chart-3" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Availability Sync</h3>
            <p class="text-sm">Real-time inventory updates</p>
        </div>
    </div>
</div>