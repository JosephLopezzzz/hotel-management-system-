<div class="space-y-6">
    <div>
        <h1>Event & Conference Management</h1>
        <p class="text-muted">Manage events, conferences, and venue bookings</p>
    </div>
    <div class="grid grid-cols-1 grid-cols-2 grid-cols-3 gap-6">
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="calendar" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Event Calendar</h3>
            <p class="text-sm">View and manage upcoming events</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="users" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Venue Management</h3>
            <p class="text-sm">Configure event spaces and capacity</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="dollar-sign" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Event Billing</h3>
            <p class="text-sm">Manage event pricing and invoices</p>
        </div>
    </div>
</div>