<div class="space-y-6">
    <div>
        <h1>Billing & Point of Sale</h1>
        <p class="text-muted">Unified billing system for rooms, restaurants, and services</p>
    </div>
    <div class="grid grid-cols-1 grid-cols-2 grid-cols-3 gap-6">
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="dollar-sign" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Guest Billing</h3>
            <p class="text-sm">Manage room charges and guest bills</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="home" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Restaurant POS</h3>
            <p class="text-sm">Process restaurant and bar orders</p>
        </div>
        <div class="p-8 border-2 border-dashed rounded-lg text-center text-muted">
            <i data-lucide="settings" class="w-12 h-12 mx-auto mb-4"></i>
            <h3>Payment Processing</h3>
            <p class="text-sm">Handle various payment methods</p>
        </div>
    </div>
</div>