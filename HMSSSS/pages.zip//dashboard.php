<?php
// Dashboard data - in a real application, this would come from a database
$occupancyData = [
    'total' => 120,
    'occupied' => 85,
    'available' => 25,
    'maintenance' => 10,
    'occupancyRate' => 71
];

$kpis = [
    [
        'title' => 'Occupancy Rate',
        'value' => '71%',
        'change' => '+5.2%',
        'icon' => 'home',
        'color' => 'text-hotel-navy'
    ],
    [
        'title' => 'Revenue Today',
        'value' => '$24,580',
        'change' => '+12.3%',
        'icon' => 'dollar-sign',
        'color' => 'text-green-600'
    ],
    [
        'title' => 'Guest Satisfaction',
        'value' => '4.8/5',
        'change' => '+0.2',
        'icon' => 'star',
        'color' => 'text-hotel-gold'
    ],
    [
        'title' => 'Upcoming Events',
        'value' => '7',
        'change' => '+2',
        'icon' => 'calendar',
        'color' => 'text-blue-600'
    ]
];

$notifications = [
    [
        'id' => 1,
        'type' => 'housekeeping',
        'message' => 'Room 205 cleaning completed',
        'time' => '5 min ago',
        'priority' => 'low'
    ],
    [
        'id' => 2,
        'type' => 'maintenance',
        'message' => 'AC repair needed in Room 312',
        'time' => '15 min ago',
        'priority' => 'high'
    ],
    [
        'id' => 3,
        'type' => 'guest',
        'message' => 'VIP guest requesting early check-in',
        'time' => '30 min ago',
        'priority' => 'medium'
    ],
    [
        'id' => 4,
        'type' => 'reservation',
        'message' => '5 new reservations for tonight',
        'time' => '1 hour ago',
        'priority' => 'low'
    ]
];

$quickActions = [
    ['label' => 'Check-in', 'icon' => 'users', 'color' => 'btn-success'],
    ['label' => 'Check-out', 'icon' => 'clock', 'color' => 'btn-primary'],
    ['label' => 'New Reservation', 'icon' => 'calendar', 'color' => 'btn-gold'],
    ['label' => 'Billing', 'icon' => 'dollar-sign', 'color' => 'btn-warning']
];
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1>Hotel Management Dashboard</h1>
            <p class="text-muted">Welcome back, Manager</p>
        </div>
        <div class="flex items-center gap-2">
            <span class="badge bg-green-50 text-green-600 border border-green-200">Online</span>
            <button class="btn btn-outline" onclick="showToast('Notifications refreshed')">
                <i data-lucide="bell"></i>
            </button>
        </div>
    </div>

    <!-- KPI Cards -->
    <div class="grid grid-cols-1 grid-cols-2 grid-cols-4 gap-6">
        <?php foreach ($kpis as $kpi): ?>
            <div class="card">
                <div class="card-header">
                    <div class="flex items-center justify-between">
                        <h4 class="text-muted"><?= htmlspecialchars($kpi['title']) ?></h4>
                        <i data-lucide="<?= $kpi['icon'] ?>" class="<?= $kpi['color'] ?>"></i>
                    </div>
                </div>
                <div class="card-content">
                    <div class="flex items-baseline gap-2">
                        <div class="text-3xl font-bold"><?= htmlspecialchars($kpi['value']) ?></div>
                        <span class="badge bg-green-50 text-green-600"><?= htmlspecialchars($kpi['change']) ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="grid grid-cols-1 grid-cols-3 gap-6">
        <!-- Room Occupancy Overview -->
        <div class="card" style="grid-column: span 2;">
            <div class="card-header">
                <h3 class="card-title">
                    <i data-lucide="home"></i>
                    Room Occupancy Overview
                </h3>
            </div>
            <div class="card-content">
                <div class="mb-6">
                    <div class="flex justify-between text-sm mb-2">
                        <span>Occupancy Rate</span>
                        <span class="font-semibold"><?= $occupancyData['occupancyRate'] ?>%</span>
                    </div>
                    <div class="progress" data-value="<?= $occupancyData['occupancyRate'] ?>">
                        <div class="progress-bar"></div>
                    </div>
                </div>
                
                <div class="grid grid-cols-4 gap-4 mb-6">
                    <div class="text-center p-4 rounded-lg border">
                        <div class="text-2xl font-bold text-hotel-navy"><?= $occupancyData['total'] ?></div>
                        <div class="text-sm text-muted">Total Rooms</div>
                    </div>
                    <div class="text-center p-4 rounded-lg border bg-red-50">
                        <div class="text-2xl font-bold text-red-600"><?= $occupancyData['occupied'] ?></div>
                        <div class="text-sm text-muted">Occupied</div>
                    </div>
                    <div class="text-center p-4 rounded-lg border bg-green-50">
                        <div class="text-2xl font-bold text-green-600"><?= $occupancyData['available'] ?></div>
                        <div class="text-sm text-muted">Available</div>
                    </div>
                    <div class="text-center p-4 rounded-lg border bg-yellow-50">
                        <div class="text-2xl font-bold text-yellow-600"><?= $occupancyData['maintenance'] ?></div>
                        <div class="text-sm text-muted">Maintenance</div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="mb-4">
                    <h4>Quick Actions</h4>
                </div>
                <div class="grid grid-cols-2 grid-cols-4 gap-2">
                    <?php foreach ($quickActions as $action): ?>
                        <button class="btn btn-outline flex-col h-auto py-4">
                            <i data-lucide="<?= $action['icon'] ?>" class="mb-2"></i>
                            <span class="text-xs"><?= htmlspecialchars($action['label']) ?></span>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Notifications Panel -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    <i data-lucide="bell"></i>
                    Notifications
                    <span class="badge badge-secondary ml-auto"><?= count($notifications) ?></span>
                </h3>
            </div>
            <div class="card-content">
                <div class="space-y-4">
                    <?php foreach ($notifications as $notification): ?>
                        <div class="flex items-start gap-3 p-3 rounded-lg border hover:bg-muted cursor-pointer">
                            <div class="w-2 h-2 rounded-full mt-2 
                                <?= $notification['priority'] === 'high' ? 'bg-red-500' : 
                                    ($notification['priority'] === 'medium' ? 'bg-yellow-500' : 'bg-green-500') ?>">
                            </div>
                            <div class="flex-1">
                                <p class="text-sm"><?= htmlspecialchars($notification['message']) ?></p>
                                <p class="text-xs text-muted"><?= htmlspecialchars($notification['time']) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <button class="btn btn-outline w-full">
                        View All Notifications
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.space-y-6 > * + * {
    margin-top: 24px;
}

.space-y-4 > * + * {
    margin-top: 16px;
}

@media (min-width: 768px) {
    .grid-cols-2 {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (min-width: 1024px) {
    .grid-cols-3 {
        grid-template-columns: repeat(3, 1fr);
    }
    
    .grid-cols-4 {
        grid-template-columns: repeat(4, 1fr);
    }
}
</style>