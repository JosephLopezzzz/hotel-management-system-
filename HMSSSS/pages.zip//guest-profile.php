<?php
$guestProfile = [
    'id' => 'GUEST001',
    'name' => 'Sarah Johnson',
    'email' => 'sarah.johnson@email.com',
    'phone' => '+1 (555) 123-4567',
    'address' => '123 Main St, New York, NY 10001',
    'loyaltyTier' => 'Gold',
    'loyaltyPoints' => 2450,
    'totalStays' => 12,
    'totalSpent' => '$4,850',
    'averageRating' => 4.8,
    'joinDate' => '2023-03-15',
    'lastStay' => '2025-07-15',
];

$preferences = [
    'roomType' => 'King Suite',
    'floor' => 'High floor',
    'view' => 'Ocean view',
    'temperature' => '72°F',
    'pillow' => 'Soft',
    'dietary' => 'Vegetarian'
];

$specialRequests = [
    'Late checkout when available',
    'Extra towels',
    'Room service breakfast at 8 AM'
];

$stayHistory = [
    [
        'id' => 'STAY001',
        'dates' => 'Jul 15-17, 2025',
        'room' => '308',
        'nights' => 2,
        'amount' => '$420',
        'rating' => 5,
        'status' => 'completed'
    ],
    [
        'id' => 'STAY002',
        'dates' => 'May 22-25, 2025',
        'room' => '205',
        'nights' => 3,
        'amount' => '$630',
        'rating' => 4,
        'status' => 'completed'
    ],
    [
        'id' => 'STAY003',
        'dates' => 'Mar 10-12, 2025',
        'room' => '412',
        'nights' => 2,
        'amount' => '$380',
        'rating' => 5,
        'status' => 'completed'
    ]
];

$upcomingReservations = [
    [
        'id' => 'RES001',
        'dates' => 'Sep 15-18, 2025',
        'room' => 'Suite 501',
        'nights' => 3,
        'amount' => '$750',
        'status' => 'confirmed'
    ]
];

$loyaltyProgress = ($guestProfile['loyaltyPoints'] % 3000) / 3000 * 100;
?>

<div class="space-y-6">
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h1>Guest Profile & CRM</h1>
            <p class="text-muted">Manage guest relationships and personalize experiences</p>
        </div>
        <div class="flex items-center gap-2">
            <button class="btn btn-outline">Export Profile</button>
            <button class="btn btn-gold">
                New Marketing Campaign
            </button>
        </div>
    </div>

    <div class="grid grid-cols-1 grid-cols-3 gap-6">
        <!-- Guest Profile Card -->
        <div class="card">
            <div class="card-header text-center">
                <div class="w-24 h-24 mx-auto bg-hotel-light-gold rounded-full flex items-center justify-center text-hotel-navy text-xl font-bold mb-4">
                    <?= strtoupper(substr($guestProfile['name'], 0, 1) . substr(explode(' ', $guestProfile['name'])[1] ?? '', 0, 1)) ?>
                </div>
                <h3 class="card-title"><?= htmlspecialchars($guestProfile['name']) ?></h3>
                <div class="flex items-center justify-center gap-2">
                    <span class="badge btn-gold">
                        <?= htmlspecialchars($guestProfile['loyaltyTier']) ?>
                    </span>
                    <div class="flex items-center gap-1">
                        <i data-lucide="star" class="text-yellow-500 fill-current"></i>
                        <span class="text-sm"><?= $guestProfile['averageRating'] ?></span>
                    </div>
                </div>
            </div>
            <div class="card-content">
                <div class="space-y-4">
                    <div class="space-y-2">
                        <div class="flex items-center gap-2 text-sm">
                            <i data-lucide="mail" class="text-muted"></i>
                            <span><?= htmlspecialchars($guestProfile['email']) ?></span>
                        </div>
                        <div class="flex items-center gap-2 text-sm">
                            <i data-lucide="phone" class="text-muted"></i>
                            <span><?= htmlspecialchars($guestProfile['phone']) ?></span>
                        </div>
                        <div class="flex items-center gap-2 text-sm">
                            <i data-lucide="map-pin" class="text-muted"></i>
                            <span><?= htmlspecialchars($guestProfile['address']) ?></span>
                        </div>
                    </div>

                    <!-- Loyalty Progress -->
                    <div class="space-y-2">
                        <div class="flex items-center justify-between text-sm">
                            <span>Loyalty Points</span>
                            <span class="font-semibold"><?= $guestProfile['loyaltyPoints'] ?></span>
                        </div>
                        <div class="progress" data-value="<?= $loyaltyProgress ?>">
                            <div class="progress-bar"></div>
                        </div>
                        <p class="text-xs text-muted">
                            <?= 3000 - ($guestProfile['loyaltyPoints'] % 3000) ?> points to next tier
                        </p>
                    </div>

                    <!-- Quick Stats -->
                    <div class="grid grid-cols-2 gap-4 pt-4 border-t">
                        <div class="text-center">
                            <div class="text-2xl font-bold text-hotel-navy"><?= $guestProfile['totalStays'] ?></div>
                            <div class="text-xs text-muted">Total Stays</div>
                        </div>
                        <div class="text-center">
                            <div class="text-2xl font-bold text-green-600"><?= $guestProfile['totalSpent'] ?></div>
                            <div class="text-xs text-muted">Total Spent</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Information -->
        <div class="card" style="grid-column: span 2;">
            <div class="tabs">
                <div class="card-header">
                    <div class="tab-list">
                        <button class="tab-trigger" data-tab="preferences">Preferences</button>
                        <button class="tab-trigger" data-tab="history">Stay History</button>
                        <button class="tab-trigger" data-tab="reservations">Reservations</button>
                        <button class="tab-trigger" data-tab="marketing">Marketing</button>
                    </div>
                </div>

                <div class="card-content">
                    <!-- Preferences Tab -->
                    <div id="preferences" class="tab-content">
                        <div class="space-y-6">
                            <div class="grid grid-cols-1 grid-cols-2 gap-6">
                                <div class="space-y-4">
                                    <h4>Room Preferences</h4>
                                    <div class="space-y-2">
                                        <?php foreach ($preferences as $key => $value): ?>
                                            <div class="flex justify-between">
                                                <span class="text-sm text-muted"><?= ucwords(str_replace(['room', 'Type'], ['Room ', ''], $key)) ?>:</span>
                                                <span class="text-sm font-semibold"><?= htmlspecialchars($value) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="space-y-4">
                                    <h4>Dining & Special Requests</h4>
                                    <div class="space-y-2">
                                        <div class="flex justify-between">
                                            <span class="text-sm text-muted">Dietary Restrictions:</span>
                                            <span class="text-sm font-semibold"><?= $preferences['dietary'] ?></span>
                                        </div>
                                    </div>
                                    <div class="space-y-2">
                                        <h5 class="text-sm font-semibold">Special Requests:</h5>
                                        <?php foreach ($specialRequests as $request): ?>
                                            <div class="flex items-center gap-2">
                                                <div class="w-2 h-2 bg-hotel-gold rounded-full"></div>
                                                <span class="text-sm"><?= htmlspecialchars($request) ?></span>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="flex justify-end gap-2">
                                <button class="btn btn-outline">Edit Preferences</button>
                                <button class="btn btn-primary">Save Changes</button>
                            </div>
                        </div>
                    </div>

                    <!-- Stay History Tab -->
                    <div id="history" class="tab-content">
                        <div class="space-y-4">
                            <?php foreach ($stayHistory as $stay): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <h4><?= htmlspecialchars($stay['dates']) ?></h4>
                                            <span class="badge badge-secondary">Room <?= $stay['room'] ?></span>
                                            <div class="flex items-center gap-1">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i data-lucide="star" class="<?= $i <= $stay['rating'] ? 'text-yellow-500 fill-current' : 'text-gray-300' ?>" style="width: 12px; height: 12px;"></i>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <p class="text-sm text-muted">
                                            <?= $stay['nights'] ?> nights • <?= $stay['amount'] ?>
                                        </p>
                                    </div>
                                    <button class="btn btn-sm btn-outline">View Details</button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Reservations Tab -->
                    <div id="reservations" class="tab-content">
                        <div class="space-y-4">
                            <h4>Upcoming Reservations</h4>
                            <?php foreach ($upcomingReservations as $reservation): ?>
                                <div class="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <h4><?= htmlspecialchars($reservation['dates']) ?></h4>
                                            <span class="badge bg-green-50 text-green-600"><?= htmlspecialchars($reservation['status']) ?></span>
                                        </div>
                                        <p class="text-sm text-muted">
                                            <?= htmlspecialchars($reservation['room']) ?> • <?= $reservation['nights'] ?> nights • <?= $reservation['amount'] ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button class="btn btn-sm btn-outline">Modify</button>
                                        <button class="btn btn-sm btn-primary">Upgrade</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Marketing Tab -->
                    <div id="marketing" class="tab-content">
                        <div class="space-y-6">
                            <div class="grid grid-cols-1 grid-cols-2 gap-6">
                                <div class="space-y-4">
                                    <h4>Campaign History</h4>
                                    <div class="space-y-2">
                                        <div class="p-3 border rounded-lg">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="font-semibold">Summer Special Offer</span>
                                                <span class="badge badge-secondary">Opened</span>
                                            </div>
                                            <p class="text-sm text-muted">Sent: Aug 10, 2025</p>
                                        </div>
                                        <div class="p-3 border rounded-lg">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="font-semibold">Loyalty Rewards Update</span>
                                                <span class="badge badge-secondary">Clicked</span>
                                            </div>
                                            <p class="text-sm text-muted">Sent: Jul 25, 2025</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="space-y-4">
                                    <h4>Recommended Campaigns</h4>
                                    <div class="space-y-2">
                                        <div class="p-3 border rounded-lg bg-hotel-light-gold bg-opacity-20">
                                            <div class="flex items-center gap-2 mb-1">
                                                <i data-lucide="gift" class="text-hotel-gold"></i>
                                                <span class="font-semibold">Birthday Special</span>
                                            </div>
                                            <p class="text-sm text-muted">Personalized birthday offer</p>
                                            <button class="btn btn-sm btn-outline mt-2">Send Campaign</button>
                                        </div>
                                        <div class="p-3 border rounded-lg">
                                            <div class="flex items-center gap-2 mb-1">
                                                <i data-lucide="heart" class="text-red-500"></i>
                                                <span class="font-semibold">VIP Upgrade Offer</span>
                                            </div>
                                            <p class="text-sm text-muted">Exclusive suite upgrade</p>
                                            <button class="btn btn-sm btn-outline mt-2">Send Campaign</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>