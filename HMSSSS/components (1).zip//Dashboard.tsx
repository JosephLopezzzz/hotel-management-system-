import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Bell, Calendar, DollarSign, Home, Star, TrendingUp, Users, Clock } from "lucide-react";

export function Dashboard() {
  const occupancyData = {
    total: 120,
    occupied: 85,
    available: 25,
    maintenance: 10,
    occupancyRate: 71
  };

  const kpis = [
    {
      title: "Occupancy Rate",
      value: "71%",
      change: "+5.2%",
      icon: Home,
      color: "text-hotel-navy"
    },
    {
      title: "Revenue Today",
      value: "$24,580",
      change: "+12.3%",
      icon: DollarSign,
      color: "text-green-600"
    },
    {
      title: "Guest Satisfaction",
      value: "4.8/5",
      change: "+0.2",
      icon: Star,
      color: "text-hotel-gold"
    },
    {
      title: "Upcoming Events",
      value: "7",
      change: "+2",
      icon: Calendar,
      color: "text-blue-600"
    }
  ];

  const notifications = [
    {
      id: 1,
      type: "housekeeping",
      message: "Room 205 cleaning completed",
      time: "5 min ago",
      priority: "low"
    },
    {
      id: 2,
      type: "maintenance",
      message: "AC repair needed in Room 312",
      time: "15 min ago",
      priority: "high"
    },
    {
      id: 3,
      type: "guest",
      message: "VIP guest requesting early check-in",
      time: "30 min ago",
      priority: "medium"
    },
    {
      id: 4,
      type: "reservation",
      message: "5 new reservations for tonight",
      time: "1 hour ago",
      priority: "low"
    }
  ];

  const quickActions = [
    { label: "Check-in", icon: Users, color: "bg-green-600" },
    { label: "Check-out", icon: Clock, color: "bg-blue-600" },
    { label: "New Reservation", icon: Calendar, color: "bg-hotel-gold" },
    { label: "Billing", icon: DollarSign, color: "bg-purple-600" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1>Hotel Management Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, Manager</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Online
          </Badge>
          <Button variant="outline" size="icon">
            <Bell className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {kpi.title}
              </CardTitle>
              <kpi.icon className={`h-4 w-4 ${kpi.color}`} />
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline space-x-2">
                <div className="text-2xl font-bold">{kpi.value}</div>
                <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                  {kpi.change}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Room Occupancy Overview */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Home className="h-5 w-5" />
              <span>Room Occupancy Overview</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Occupancy Rate</span>
                <span className="font-medium">{occupancyData.occupancyRate}%</span>
              </div>
              <Progress value={occupancyData.occupancyRate} className="h-3" />
            </div>
            
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-lg border">
                <div className="text-2xl font-bold text-hotel-navy">{occupancyData.total}</div>
                <div className="text-sm text-muted-foreground">Total Rooms</div>
              </div>
              <div className="text-center p-4 rounded-lg border bg-red-50">
                <div className="text-2xl font-bold text-red-600">{occupancyData.occupied}</div>
                <div className="text-sm text-muted-foreground">Occupied</div>
              </div>
              <div className="text-center p-4 rounded-lg border bg-green-50">
                <div className="text-2xl font-bold text-green-600">{occupancyData.available}</div>
                <div className="text-sm text-muted-foreground">Available</div>
              </div>
              <div className="text-center p-4 rounded-lg border bg-yellow-50">
                <div className="text-2xl font-bold text-yellow-600">{occupancyData.maintenance}</div>
                <div className="text-sm text-muted-foreground">Maintenance</div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-3">
              <h4>Quick Actions</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="flex flex-col items-center space-y-2 h-auto py-4 hover:shadow-md"
                  >
                    <action.icon className={`h-5 w-5 text-white`} />
                    <span className="text-xs">{action.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications Panel */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span>Notifications</span>
              <Badge variant="secondary" className="ml-auto">
                {notifications.length}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer"
              >
                <div
                  className={`w-2 h-2 rounded-full mt-2 ${
                    notification.priority === "high"
                      ? "bg-red-500"
                      : notification.priority === "medium"
                      ? "bg-yellow-500"
                      : "bg-green-500"
                  }`}
                />
                <div className="flex-1 space-y-1">
                  <p className="text-sm">{notification.message}</p>
                  <p className="text-xs text-muted-foreground">{notification.time}</p>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full">
              View All Notifications
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}